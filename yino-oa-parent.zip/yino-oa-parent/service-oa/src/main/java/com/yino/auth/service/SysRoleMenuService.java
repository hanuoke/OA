package com.yino.auth.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.yino.model.system.SysRoleMenu;

/**
 * <p>
 * 角色菜单 服务类
 * </p>
 *
 * @author yino
 * @since 2023-04-03
 */
public interface SysRoleMenuService extends IService<SysRoleMenu> {

}
