<template>
  <div>
    <div>账号切换</div>
    <button @click="xkfzr()" type="default" size="mini">张学科</button>
    <button @click="zs()" type="default" size="mini">张三</button>
    <button @click="ls()" type="default" size="mini">李四</button>
    <div>当前token：{{ token }}</div>
  </div>
</template>

<script>
export default {
  name: "Test",

  data() {
    return {
      token: ''
    };
  },

  created(){
    this.token = window.localStorage.getItem('token')
  },

  methods: {
    xkfzr() {
      window.localStorage.setItem('token', '');
      let token = 'eyJhbGciOiJIUzUxMiIsInppcCI6IkdaSVAifQ.H4sIAAAAAAAAAKtWKi5NUrJScgwN8dANDXYNUtJRSq0oULIyNLMwsjQ0Njax0FEqLU4t8kxRsjKDMPMSc1OBWiqy06qKlGoBLcrrOUIAAAA.jck1tRNAeYjlEKc12ODCyBAHm_coiIGbX44D18b4MQ6CgL4osTo7OH5VqMC5uy1tUc61aVopjNR_keESVWZMww'
      window.localStorage.setItem('token', token);
      this.token = window.localStorage.getItem('token')
    },

    zs() {
      window.localStorage.setItem('token', '');
      let token = 'eyJhbGciOiJIUzUxMiIsInppcCI6IkdaSVAifQ.H4sIAAAAAAAAAKtWKi5NUrJScgwN8dANDXYNUtJRSq0oULIyNLMwsjQ0NjAx11EqLU4t8kxRsoIy8xJzU4FaqjIS89KLE_OUagGW85X4RQAAAA.C938NSGQN3DJv0JzX4GwJHD2b5g7HqUDYnLu4TzF755z_On-ur0J9VBB1eCn9-Ibv228jw6wxZtoo15t4EoqxA'
      window.localStorage.setItem('token', token);
      this.token = window.localStorage.getItem('token')
    },

    ls() {
      window.localStorage.setItem('token', '');
      let token = 'eyJhbGciOiJIUzUxMiIsInppcCI6IkdaSVAifQ.H4sIAAAAAAAAAKtWKi5NUrJScgwN8dANDXYNUtJRSq0oULIyNLMwsjQ0NjC30FEqLU4t8kxRsjKBMPMSc1OBWnIyizOVagHG6JplQQAAAA.UF8g7AF38NwvubtLSZtZCIHk1qJ-g4ezqWpwzafU9ndw-D-35lmeQ0zODOE8rAaQn33IjY61J4d-XLDNaYirCw'
      window.localStorage.setItem('token', token);
      this.token = window.localStorage.getItem('token')
    },

    lisi() {
      window.localStorage.setItem('token', '');
      let token = 'eyJhbGciOiJIUzUxMiIsInppcCI6IkdaSVAifQ.H4sIAAAAAAAAAKtWKi5NUrJScgwN8dANDXYNUtJRSq0oULIyNDM3NjMwNDGy0FEqLU4t8kxRsjKBMPMSc1OBWnIyizOVagHMg0O1QQAAAA.bQBo4zc1rtT0b6Mq3OmuM6cq3Oe2RpA01GR77Pql84W3ojhdEcjLF2z5ZQfTuoCEkA45ZeXOVqXmSJa3TXfe5g'
      window.localStorage.setItem('token', token);
      this.token = window.localStorage.getItem('token')
    }
  }
}
</script>
